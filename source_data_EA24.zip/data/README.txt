This directory contains text files with data from Eisenman & Armour, "The radiative feedback continuum from Snowball Earth to an ice-free hothouse", Nature Communications 2024.

The files have all the data necessary to recreate the line plots in Figs. 1-4 of the paper. The header of each file lists which fields it contains. Each file header also includes Matlab code to recreate the line plots. Note that some data (such as the annual-mean global-mean surface temperature) is included in multiple files because it is needed for multiple figures.

The figure captions in the paper provide further details regarding this data.
